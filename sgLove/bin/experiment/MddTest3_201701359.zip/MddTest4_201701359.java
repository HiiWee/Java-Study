package experiment;

import java.util.Scanner;

public class MddTest4_201701359 {

	public static void main(String[] args) {
		int[][] arr = new int[100][100];
		Scanner scan = new Scanner(System.in);

		int n = scan.nextInt();
		int m = scan.nextInt();
		int reverse = 0;
		int reverseCnt = 1;
		int count = 1;

		for (int i = m - 1; i >= 0; i--) {
			
			if (i == m - 1 - reverse) {
				for (int j = n - 1; j >= 0; j--) {
					arr[j][i] = count++;
				}
				reverse = 2 * reverseCnt;
				reverseCnt++;
			}
			
			else {
				for (int j = 0; j < n; j++) {
					arr[j][i] = count++;
				}
			}
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}

	}

}
