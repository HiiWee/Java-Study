package experiment;

import java.util.Scanner;

public class MddTest1_201701359 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int num;
		int sum = 0;
		int flag = 0;
		for (int i = 0; i < 7; i++) {
			num = scan.nextInt();
			if (num % 2 == 1) {
				sum += num;
				flag = 1;
			}
		}
		if (flag == 1) {
			System.out.println(sum);
		}
		else {
			System.out.println(-1);
		}
	}

}
