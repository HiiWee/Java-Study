package experiment;

import java.util.Scanner;

public class MddTest2_201701359 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int a, b, c;

		a = n / 10;
		b = n % 10;
		c = (b * 10 + a) * 2;

		if (c > 100) {
			c = c - 100;
		}
		if (c <= 50) {
			System.out.println(c);
			System.out.println("GOOD");
		} else {
			System.out.println(c);
			System.out.println("OH MY GOD");
		}
	}

}
